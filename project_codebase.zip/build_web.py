#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import json
import shutil
from datetime import datetime
import openpyxl

BASE_DIR = "/Users/nb/google/Antigravity/工作/运营/价单"
WEB_DIR = os.path.join(BASE_DIR, "web")
FILES_DIR = os.path.join(WEB_DIR, "files")

def ensure_dirs():
    """确保网页输出目录和文件存储目录存在，并清空旧的 files 目录以防遗留售罄项目"""
    os.makedirs(WEB_DIR, exist_ok=True)
    if os.path.exists(FILES_DIR):
        shutil.rmtree(FILES_DIR)
    os.makedirs(FILES_DIR, exist_ok=True)

def parse_project_stats(file_path):
    """
    通过只读模式打开 Excel，读取'销控汇总明细'表，计算项目销控状态统计。
    """
    stats = {
        'total': 0,
        'sold': 0,
        'sale': 0,
        'priced': 0,
        'stopped': 0,
        'pending': 0,
        'sold_rate': 0.0
    }
    
    if not os.path.exists(file_path):
        return stats
        
    try:
        # 使用 read_only=True 极速读取
        wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
        if "销控汇总明细" in wb.sheetnames:
            ws = wb["销控汇总明细"]
            # 找到状态列的索引 (第一行可能是标题，第二行是表头)
            # 表头是：["楼栋", "楼层", "房号", "户型", "实用面积 (平方呎)", "销控状态", "成交日期", "总价 (港币)", "实用呎价 (港币/呎)", "是否招标"]
            # 销控状态在第 6 列 (index 5)
            
            row_count = 0
            for row in ws.iter_rows(min_row=3, max_col=6, values_only=True):
                # 检查是否是空行 (第一列"楼栋"为空则视为结束)
                if not row or row[0] is None:
                    break
                
                status_val = row[5] if len(row) >= 6 else None
                if status_val:
                    status_str = str(status_val).strip()
                    row_count += 1
                    
                    if status_str == '已售':
                        stats['sold'] += 1
                    elif status_str == '在售':
                        stats['sale'] += 1
                    elif status_str == '已定价未售':
                        stats['priced'] += 1
                    elif status_str == '暂停销售':
                        stats['stopped'] += 1
                    elif status_str == '待售':
                        stats['pending'] += 1
                    else:
                        # 兼容处理
                        if '售' in status_str and '未售' not in status_str and '待售' not in status_str and '暂停' not in status_str:
                            stats['sold'] += 1
                        else:
                            stats['pending'] += 1
            
            stats['total'] = row_count
            if stats['total'] > 0:
                stats['sold_rate'] = round((stats['sold'] / stats['total']) * 100, 1)
        wb.close()
    except Exception as e:
        print(f"警告: 读取 Excel {file_path} 统计信息失败: {e}")
        
    return stats

def main():
    print("开始扫描价单目录并构建网页数据库...")
    ensure_dirs()
    
    projects_list = []
    
    # 统计汇总
    global_stats = {
        'total_projects': 0,
        'total_units': 0,
        'total_sold': 0,
        'total_sale': 0,
        'total_priced': 0,
        'total_stopped': 0,
        'total_pending': 0,
        'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    # 遍历 BASE_DIR 下的子文件夹
    for d in sorted(os.listdir(BASE_DIR)):
        dir_path = os.path.join(BASE_DIR, d)
        if not os.path.isdir(dir_path):
            continue
            
        # 忽略 .agents, web 等目录
        if d.startswith('.') or d in ['web', 'scratch']:
            continue
            
        # 解析文件夹命名：{区域}-{商圈}-{项目名称}
        parts = d.split('-')
        if len(parts) < 3:
            continue
            
        region = parts[0].strip()
        district = parts[1].strip()
        project_name = "-".join(parts[2:]).strip() # 项目名称可能有横杠
        
        # 寻找对应的 Excel 销控表：{项目名称}_销控明细表.xlsx
        excel_filename = f"{project_name}_销控明细表.xlsx"
        src_excel_path = os.path.join(dir_path, excel_filename)
        
        if not os.path.exists(src_excel_path):
            # 尝试不区分大小写或者模糊匹配
            found = False
            for file in os.listdir(dir_path):
                if file.endswith("_销控明细表.xlsx"):
                    src_excel_path = os.path.join(dir_path, file)
                    excel_filename = file
                    found = True
                    break
            if not found:
                print(f"跳过: {d} (未找到销控明细表 Excel)")
                continue
        
        print(f"处理项目: {region} -> {district} -> {project_name}")
        
        # 1. 统计数据
        stats = parse_project_stats(src_excel_path)
        
        # 1.1 过滤售罄项目 (去化率达 100% 的项目在网页端不予展示)
        if stats['total'] > 0 and stats['sold'] == stats['total']:
            print(f"  [网页过滤] 项目 {project_name} 已售罄 (100%)，不展示在网页端。")
            continue
        
        # 2. 拷贝 Excel 文件到 web/files/ 并规范重命名为 {区域}-{商圈}-{项目名称}.xlsx
        dest_filename = f"{region}-{district}-{project_name}.xlsx"
        dest_excel_path = os.path.join(FILES_DIR, dest_filename)
        
        try:
            shutil.copy2(src_excel_path, dest_excel_path)
            file_size_kb = round(os.path.getsize(dest_excel_path) / 1024, 1)
        except Exception as e:
            print(f"错误: 拷贝文件 {excel_filename} 失败: {e}")
            continue
            
        # 获取文件修改时间作为更新时间
        mtime = os.path.getmtime(src_excel_path)
        last_updated_date = datetime.fromtimestamp(mtime).strftime('%Y-%m-%d')
        
        # 3. 收集项目信息
        proj_info = {
            'name': project_name,
            'region': region,
            'district': district,
            'filename': dest_filename,
            'file_size_kb': file_size_kb,
            'stats': stats,
            'last_updated': last_updated_date
        }
        projects_list.append(proj_info)
        
        # 累加全局统计
        global_stats['total_projects'] += 1
        global_stats['total_units'] += stats['total']
        global_stats['total_sold'] += stats['sold']
        global_stats['total_sale'] += stats['sale']
        global_stats['total_priced'] += stats['priced']
        global_stats['total_stopped'] += stats['stopped']
        global_stats['total_pending'] += stats['pending']

    # 计算全局去化率
    if global_stats['total_units'] > 0:
        global_stats['overall_sold_rate'] = round((global_stats['total_sold'] / global_stats['total_units']) * 100, 1)
    else:
        global_stats['overall_sold_rate'] = 0.0

    # 导出 json 数据库
    db_data = {
        'global_stats': global_stats,
        'projects': projects_list
    }
    
    json_path = os.path.join(WEB_DIR, "data.json")
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(db_data, f, ensure_ascii=False, indent=2)
        
    print(f"\n构建成功! 共处理 {global_stats['total_projects']} 个项目。")
    print(f"数据索引已写入: {json_path}")
    print(f"静态文件已整理至: {FILES_DIR}")

if __name__ == "__main__":
    main()
